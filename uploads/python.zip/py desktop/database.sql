-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bus
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--
create database bus;
use bus;
DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `tripcode` int NOT NULL,
  `userid` int NOT NULL,
  `transactionid` int NOT NULL AUTO_INCREMENT,
  `amount` int NOT NULL,
  `dateofpayment` date NOT NULL,
  `busid` int NOT NULL,
  PRIMARY KEY (`transactionid`),
  KEY `tripcode` (`tripcode`),
  KEY `userid` (`userid`),
  KEY `busid` (`busid`),
  CONSTRAINT `account_ibfk_1` FOREIGN KEY (`tripcode`) REFERENCES `passanger` (`tripcode`),
  CONSTRAINT `account_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`),
  CONSTRAINT `account_ibfk_3` FOREIGN KEY (`busid`) REFERENCES `bus` (`busid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking` (
  `tripcode` int NOT NULL,
  `busid` int NOT NULL,
  `seatnumber` int NOT NULL,
  `name` varchar(255) NOT NULL,
  KEY `tripcode` (`tripcode`),
  KEY `busid` (`busid`),
  CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`tripcode`) REFERENCES `passanger` (`tripcode`),
  CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`busid`) REFERENCES `bus` (`busid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES (123456,1,2,'bhargav'),(123456,1,6,'bhargav'),(123456,1,10,'bhargav'),(4718,1,14,'9426027083'),(4718,1,15,'9426027083'),(1314,1,38,'9426027083'),(1314,1,39,'9426027083'),(2662,3,14,'9426027083'),(2662,3,15,'9426027083'),(2662,3,16,'9426027083'),(5605,1,23,'9426027083'),(5605,1,28,'9426027083'),(3050,1,17,'9426027083'),(3050,1,16,'9426027083'),(4970,1,20,'9426027083'),(4970,1,22,'9426027083'),(1814,3,22,'9426027083'),(1814,3,26,'9426027083'),(1814,3,30,'9426027083'),(9118,2,18,'98756321'),(9118,2,19,'98756321'),(8863,1,29,'9874563210'),(8863,1,32,'9874563210'),(8863,1,36,'9874563210'),(1199,3,5,'1236547890'),(1199,3,7,'1236547890'),(9208,1,7,'0123456789'),(9208,1,8,'0123456789'),(5351,1,11,'9426027083'),(5351,1,12,'9426027083'),(2620,1,30,'9426027083'),(2620,1,26,'9426027083'),(8275,2,30,'4567891230'),(8275,2,35,'4567891230'),(8275,2,32,'4567891230'),(2987,2,2,'9426027083'),(2987,2,3,'9426027083');
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bus`
--

DROP TABLE IF EXISTS `bus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bus` (
  `busid` int NOT NULL AUTO_INCREMENT,
  `routeid` int NOT NULL,
  `busnumber` int NOT NULL,
  PRIMARY KEY (`busid`),
  UNIQUE KEY `busnumber` (`busnumber`),
  KEY `routeid` (`routeid`),
  CONSTRAINT `bus_ibfk_1` FOREIGN KEY (`routeid`) REFERENCES `route` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus`
--

LOCK TABLES `bus` WRITE;
/*!40000 ALTER TABLE `bus` DISABLE KEYS */;
INSERT INTO `bus` VALUES (1,1,123456),(2,2,1212),(3,3,7878);
/*!40000 ALTER TABLE `bus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbetween`
--

DROP TABLE IF EXISTS `inbetween`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inbetween` (
  `routid` int NOT NULL,
  `stationid` int NOT NULL,
  `kilometres` int NOT NULL,
  `stopnumber` int NOT NULL,
  `time` time NOT NULL,
  KEY `routid` (`routid`),
  KEY `stationid` (`stationid`),
  CONSTRAINT `inbetween_ibfk_1` FOREIGN KEY (`routid`) REFERENCES `route` (`id`),
  CONSTRAINT `inbetween_ibfk_2` FOREIGN KEY (`stationid`) REFERENCES `station` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbetween`
--

LOCK TABLES `inbetween` WRITE;
/*!40000 ALTER TABLE `inbetween` DISABLE KEYS */;
INSERT INTO `inbetween` VALUES (1,4,0,0,'11:00:00'),(1,7,30,1,'12:00:00'),(1,5,50,2,'12:30:00'),(1,6,80,3,'01:00:00'),(1,1,120,4,'02:00:00'),(2,4,0,0,'08:30:00'),(2,3,30,1,'09:30:00'),(2,9,50,2,'10:00:00'),(2,8,70,3,'10:30:00'),(2,2,90,4,'11:00:00'),(3,4,0,0,'09:00:00'),(3,3,30,1,'09:00:00');
/*!40000 ALTER TABLE `inbetween` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passanger`
--

DROP TABLE IF EXISTS `passanger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passanger` (
  `tripcode` int NOT NULL AUTO_INCREMENT,
  `passangerid` int NOT NULL,
  `amount` int NOT NULL,
  `from_location` varchar(255) NOT NULL,
  `to_location` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `noodseat` int NOT NULL,
  PRIMARY KEY (`tripcode`),
  KEY `passangerid` (`passangerid`),
  CONSTRAINT `passanger_ibfk_1` FOREIGN KEY (`passangerid`) REFERENCES `users` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=123457 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passanger`
--

LOCK TABLES `passanger` WRITE;
/*!40000 ALTER TABLE `passanger` DISABLE KEYS */;
INSERT INTO `passanger` VALUES (1199,770,48,'dhrangadhra','surendranagar','2023-12-30',2),(1314,718,192,'dhrangadhra','amdavad','2023-12-29',2),(1814,267,72,'dhrangadhra','surendranagar','2023-12-29',3),(2620,799,192,'dhrangadhra','amdavad','2023-12-30',2),(2662,813,72,'dhrangadhra','surendranagar','2023-12-29',3),(2987,403,32,'surendranagar','muli','2023-12-30',2),(3050,193,192,'dhrangadhra','amdavad','2023-12-29',2),(4718,625,192,'dhrangadhra','amdavad','2023-12-29',2),(4970,677,192,'dhrangadhra','amdavad','2023-12-29',2),(5351,847,192,'dhrangadhra','amdavad','2023-12-30',2),(5605,914,192,'dhrangadhra','amdavad','2023-12-22',2),(8275,127,48,'surendranagar','muli','2023-12-31',3),(8863,107,288,'dhrangadhra','amdavad','2023-12-30',3),(9118,239,96,'surendranagar','rajkot','2023-12-30',2),(9208,920,192,'dhrangadhra','amdavad','2023-12-30',2),(123456,1,96,'dhrangadhra','amdavad','2023-12-29',4);
/*!40000 ALTER TABLE `passanger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fromstation` int NOT NULL,
  `tostation` int NOT NULL,
  `startime` time NOT NULL,
  `stoptime` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromstation` (`fromstation`),
  KEY `tostation` (`tostation`),
  CONSTRAINT `route_ibfk_1` FOREIGN KEY (`fromstation`) REFERENCES `station` (`id`),
  CONSTRAINT `route_ibfk_2` FOREIGN KEY (`tostation`) REFERENCES `station` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route`
--

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` VALUES (1,4,1,'11:20:00','02:00:00'),(2,4,2,'08:30:00','11:00:00'),(3,4,3,'09:00:00','10:00:00');
/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `station`
--

DROP TABLE IF EXISTS `station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `station` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station`
--

LOCK TABLES `station` WRITE;
/*!40000 ALTER TABLE `station` DISABLE KEYS */;
INSERT INTO `station` VALUES (1,'amdavad'),(2,'rajkot'),(3,'surendranagar'),(4,'dhrangadhra'),(5,'viramgam'),(6,'sanad'),(7,'malavan'),(8,'chotila'),(9,'muli');
/*!40000 ALTER TABLE `station` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `useremail` varchar(255) NOT NULL,
  `usernumber` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `useremail` (`useremail`)
) ENGINE=InnoDB AUTO_INCREMENT=321511115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'bhargav','bb@gmail.com','9426027083'),(107,'darshan','darshan.jadav1188@gmail.com','9874563210'),(127,'darshan','darshan.jadav1188@gmail.com','4567891230'),(193,'bhargav','bhargavmbhatt24@gmail.com','9426027083'),(239,'aditya','adityapithva36@gmail.com','98756321'),(267,'bhargav','bhargavmbhatt24@gmail.com','9426027083'),(403,'bhargav','bhargavmbhatt24@gmail.com','9426027083'),(625,'bhargav','bhargavmbhatt24@outlook.com','9426027083'),(677,'bhargav','bhargavmbhatt24@outlook.com','9426027083'),(718,'bhargav','bhargavmbhatt24@gmail.com','9426027083'),(770,'darshan','darshan.jadav1188@gmail.com','1236547890'),(799,'darshan','darshan.jadav1188@gmail.com','9426027083'),(813,'bhargav','bhargavmbhatt24@gmail.com','9426027083'),(847,'bhargav','bhargavmbhatt24@gmail.com','9426027083'),(914,'bhargav','bhargavmbhatt24@gmail.com','9426027083'),(920,'darshan','darshan.jadav1188@gmail.com','0123456789');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-04 13:23:38
